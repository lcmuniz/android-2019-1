package com.acme.brapp;

public class MensagemActions {
    public static final String MENSAGEM1_ACTION = "com.acme.brapp.mensagem1";
    public static final String MENSAGEM2_ACTION = "com.acme.brapp.mensagem2";
}
