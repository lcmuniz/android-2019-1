package com.acme.brapp;

class Mensagem2 {
    private String mensagem;

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }
}
