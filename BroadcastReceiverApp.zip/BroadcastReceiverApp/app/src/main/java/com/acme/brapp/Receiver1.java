package com.acme.brapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.Date;

public class Receiver1 extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        String mensagem = intent.getStringExtra("mensagem");
        Date data = (Date) intent.getSerializableExtra("data");

        Intent inte = new Intent(context, MostraMensagem.class);
        inte.putExtra("mensagem", mensagem + " em " + data);
        context.startActivity(inte);

    }
}
