package com.acme.brapp;

import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.greenrobot.eventbus.EventBus;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    // broadcast receivers
    Receiver1 receiver1 = new Receiver1();
    Receiver2 receiver2 = new Receiver2();

    // subscritores do eventbus
    Subscritor1 sub1 = new Subscritor1(this);
    Subscritor2 sub2 = new Subscritor2();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // registrando broadcast receivers
        registerReceiver(receiver1, new IntentFilter(MensagemActions.MENSAGEM1_ACTION));
        registerReceiver(receiver2, new IntentFilter(MensagemActions.MENSAGEM1_ACTION));
        registerReceiver(receiver2, new IntentFilter(MensagemActions.MENSAGEM2_ACTION));

        Button broadcastButton = findViewById(R.id.broadcastButton);
        broadcastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // enviando mensagens via broadcast
                Intent intent1 = new Intent();
                intent1.setAction(MensagemActions.MENSAGEM1_ACTION);
                intent1.putExtra("mensagem", "Olá Mundo!");
                intent1.putExtra("data", new Date());
                sendBroadcast(intent1);

                Intent intent2 = new Intent();
                intent2.setAction(MensagemActions.MENSAGEM2_ACTION);
                intent2.putExtra("mensagem", "Olá Pessoal!");
                sendBroadcast(intent2);

                // enviando mensagens via eventbus
                Mensagem1 m1 = new Mensagem1();
                m1.setMensagem("Olá Mundo!");
                m1.setData(new Date());
                EventBus.getDefault().post(m1);

                Mensagem2 m2 = new Mensagem2();
                m2.setMensagem("Olá Pessoal!");
                EventBus.getDefault().post(m2);

            }
        });

    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(receiver1);
        unregisterReceiver(receiver2);
        super.onDestroy();
    }
}
