package com.acme.brapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class Receiver2 extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        String m = intent.getStringExtra("mensagem").toUpperCase();

        if (intent.getAction().equals(MensagemActions.MENSAGEM1_ACTION)) {
            System.out.println("Receiver2: " + m.toUpperCase());
        }
        else if (intent.getAction().equals(MensagemActions.MENSAGEM2_ACTION)) {
            System.out.println("Receiver2: " + m.toLowerCase());
        }


    }
}
