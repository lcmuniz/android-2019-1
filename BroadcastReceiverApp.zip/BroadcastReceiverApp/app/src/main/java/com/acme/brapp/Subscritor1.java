package com.acme.brapp;

import android.app.Activity;
import android.content.Intent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Subscritor1 {

    private final Activity activity;

    public Subscritor1(Activity activity) {
        this.activity = activity;
        EventBus.getDefault().register(this);
    }

    @Subscribe
    public void on(Mensagem1 m1) {

        //Intent inte = new Intent(activity, MostraMensagem.class);
        //inte.putExtra("mensagem", m1.getMensagem() + " em " + m1.getData());
        //activity.startActivity(inte);

    }

}
