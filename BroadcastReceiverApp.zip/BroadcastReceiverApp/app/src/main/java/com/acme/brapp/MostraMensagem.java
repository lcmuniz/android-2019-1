package com.acme.brapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MostraMensagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostra_mensagem);

        TextView mensaTextView = findViewById(R.id.mensagemTextView);

        String mensagem = getIntent().getStringExtra("mensagem");
        mensaTextView.setText(mensagem);


    }
}
