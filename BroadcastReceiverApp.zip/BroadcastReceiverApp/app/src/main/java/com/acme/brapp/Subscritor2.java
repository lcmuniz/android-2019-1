package com.acme.brapp;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class Subscritor2 {

    public Subscritor2() {
        EventBus.getDefault().register(this);
    }

    @Subscribe
    public void on(Mensagem1 m1) {
        System.out.println("Subscritor2: " + m1.getMensagem().toUpperCase());
    }

    @Subscribe
    public void on(Mensagem2 m2) {
        System.out.println("Subscritor2: " + m2.getMensagem().toLowerCase());
    }


}
