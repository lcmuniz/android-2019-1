package com.acme.brapp;

import java.io.Serializable;
import java.util.Date;

class Mensagem1 implements Serializable {
    private String mensagem;
    private Date data;

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Date getData() {
        return data;
    }
}
