package course.labs.labintents;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AtivacaoExplicitaActivity extends AppCompatActivity {

    static private final String TAG = "Lab-Intents";

    private EditText editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_ativacao_explicita);

        // Obtém uma referência ao EditText
        editText = findViewById(R.id.editText);

        // Declara e configura o botão "OK"
        Button okButton = findViewById(R.id.ok_button);
        okButton.setOnClickListener(new View.OnClickListener() {

            // Chama okClicado() quando pressionado

            @Override
            public void onClick(View v) {

                okClicado();

            }
        });

    }

    // Define o resultado para enviar de volta à Activity que chamou e finaliza

    private void okClicado() {

        Log.i(TAG,"Entrou em okClicado()");

        // TODO - Salvar a entrada do usuário do campo EditText

        // TODO - Criar uma nova intent e salvar a entrada do campo EditText como um extra

        // TODO - Definir o resultado da Activity com o result code RESULT_OK

        // TODO - Finalizar a Activity

    }

}
