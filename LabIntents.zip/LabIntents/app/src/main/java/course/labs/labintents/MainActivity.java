package course.labs.labintents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    static private final int GET_TEXT_REQUEST_CODE = 1;
    static private final String URL = "http://www.google.com";
    static private final String TAG = "LabIntents";

    // Para uso do seletor de aplicativo
    static private final String TEXTO_DO_SELETOR = "Abrir " + URL + " com:";

    // TextView que mostra o texto entrado pelo usuário
    // na AtivacaoExplicitaActivity
    private TextView usuarioTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtém a referência à textView
        usuarioTextView = (TextView) findViewById(R.id.textView1);

        // Declara e configura o botão Ativação Explícita
        Button ativacaoExplicitaButton = findViewById(R.id.ativacao_explicita_button);
        ativacaoExplicitaButton.setOnClickListener(new View.OnClickListener() {

            // Chama iniciarAtivacaoExplicita quando pressionado
            @Override
            public void onClick(View v) {

                iniciarAtivacaoExplicita();

            }
        });

        // Declara e configura o botão Ativação Implícita
        Button ativacaoImplicitaButton = findViewById(R.id.ativacao_implicita_button);
        ativacaoImplicitaButton.setOnClickListener(new View.OnClickListener() {

            // Call iniciarAtivacaoImplicita() when pressed
            @Override
            public void onClick(View v) {

                iniciarAtivacaoImplicita();

            }
        });

    }


    // Inicia a AtivacaoExplicitaActivity

    private void iniciarAtivacaoExplicita() {

        Log.i(TAG,"Entrou em iniciarAtivacaoExplicita()");

        // TODO - Criar uma nova intent para iniciar a classe AtivacaoExplicitaActivity
        Intent explicitaIntent = null;

        // TODO - Iniciar uma Activity usando a intent e o request code definido acima



    }

    // Inicia um Browser para visualizar uma página web

    private void iniciarAtivacaoImplicita() {

        Log.i(TAG, "Entrou em iniciarAtivacaoImplicita()");

        // TODO - Criar uma intent para visualizar uma URL
        // (DICA:  o segundo parâmetro usa Uri.parse())

        Intent baseIntent = null;

        // TODO - Criar uma intent seletora para escolher qual Activity
        // irá se encarregar de baseIntent
        // (DICA: Use o método createChooser() da classe Intent)
        Intent intentSeletora = null;


        Log.i(TAG,"Action da Intent Seletora:" + intentSeletora.getAction());


        // TODO - Iniciar o seletor, usando a intentSeletora


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.i(TAG, "Entrou em onActivityResult()");

        // TODO - Processa o resultado somente se este método recebeu um
        // código RESULT_OK e o request code definido acima
        // Se sim, atualizar o Textview para mostrar o texto digitado pelo usuário.






    }

}
