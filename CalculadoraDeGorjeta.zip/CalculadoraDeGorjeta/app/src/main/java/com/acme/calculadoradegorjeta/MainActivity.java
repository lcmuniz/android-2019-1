package com.acme.calculadoradegorjeta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String TOTAL_CONTA = "TOTAL_CONTA";
    private static final String PORCENTAGEM_ATUAL = "PORCENTAGEM_ATUAL";

    private EditText gorjeta10EditText;
    private EditText total10EditText;
    private EditText gorjeta15EditText;
    private EditText total15EditText;
    private EditText gorjeta20EditText;
    private EditText total20EditText;
    private TextView percentagemGorjetaTextView;
    private EditText gorjetaPersonalizadaEditText;
    private EditText totalPersonalizadaEditText;
    private EditText contaEditText;
    private SeekBar gorjetaSeekBar;

    private double totalDaConta;
    private int porcentagemAtual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        restaurarEstado(savedInstanceState);

        initViews();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putDouble(TOTAL_CONTA,  totalDaConta);
        outState.putInt(PORCENTAGEM_ATUAL, porcentagemAtual);
    }

    private void restaurarEstado(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            // o aplicativo acabou de ser iniciado
            totalDaConta = 0.0;
            porcentagemAtual = 18;
        }
        else {
            // o aplicativo está sendo restaurado da memória
            totalDaConta = savedInstanceState.getDouble(TOTAL_CONTA);
            porcentagemAtual = savedInstanceState.getInt(PORCENTAGEM_ATUAL);
        }
    }

    private void initViews() {

        // referências para os EditText de 10%, 15%, 20% e total
        gorjeta10EditText = findViewById(R.id.gorjeta10EditText);
        total10EditText = findViewById(R.id.total10EditText);
        gorjeta15EditText = findViewById(R.id.gorjeta15EditText);
        total15EditText = findViewById(R.id.total15EditText);
        gorjeta20EditText = findViewById(R.id.gorjeta20EditText);
        total20EditText = findViewById(R.id.total20EditText);

        // referência para o TextView da percentagem da gorjeta personaliza
        percentagemGorjetaTextView = findViewById(R.id.percentagemGorjetaTextView);

        // referências para os EdiText da gorjeta personaliza e total
        gorjetaPersonalizadaEditText = findViewById(R.id.gorjetaPersonalizadaEditText);
        totalPersonalizadaEditText = findViewById(R.id.totalPersonalizadaEditText);

        // referência para o EditTexto com o valor da conta
        contaEditText = findViewById(R.id.contaEditText);

        // lidar com o evento de mudança no valor da conta
        contaEditText.addTextChangedListener(contaEditTextListener);

        // referência ao SeekBar
        gorjetaSeekBar = findViewById(R.id.gorjetaSeekBar);

        // lidar com o evento de alteração na SeekBar
        gorjetaSeekBar.setOnSeekBarChangeListener(seekBarListener);
    }

    TextWatcher contaEditTextListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            try {
                totalDaConta = Double.parseDouble(s.toString());
            }
            catch (NumberFormatException nfe) {
                totalDaConta = 0.0;
            }

            atualizarGorjetasPadrao();
            atualizarGorjetaPersonalizada();
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };


    SeekBar.OnSeekBarChangeListener seekBarListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            porcentagemAtual = seekBar.getProgress();
            atualizarGorjetaPersonalizada();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };

    // atualiza os EditText de 10%, 15% e 20%
    private void atualizarGorjetasPadrao() {

        double gorjeta10 = totalDaConta * 0.10;
        double gorjeta15 = totalDaConta * 0.15;
        double gorjeta20 = totalDaConta * 0.20;

        double total10 = totalDaConta + gorjeta10;
        double total15 = totalDaConta + gorjeta15;
        double total20 = totalDaConta + gorjeta20;

        gorjeta10EditText.setText(String.format("%.02f", gorjeta10));
        gorjeta15EditText.setText(String.format("%.02f", gorjeta15));
        gorjeta20EditText.setText(String.format("%.02f", gorjeta20));

        total10EditText.setText(String.format("%.02f", total10));
        total15EditText.setText(String.format("%.02f", total15));
        total20EditText.setText(String.format("%.02f", total20));
    }

    private void atualizarGorjetaPersonalizada() {
        percentagemGorjetaTextView.setText(porcentagemAtual + "%");

        double gorjeta = totalDaConta * porcentagemAtual * 0.01;

        double total = totalDaConta + gorjeta;

        gorjetaPersonalizadaEditText.setText(String.format("%.02f", gorjeta));
        totalPersonalizadaEditText.setText(String.format("%.02f", total));
    }

}
