package course.labs.notificacaoapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import course.labs.notificacaoapp.mensagem.TarefaConcluida;
import course.labs.notificacaoapp.tarefas.Tarefa;

public class MainActivity extends AppCompatActivity {

    private static final int NOTIF_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EventBus.getDefault().register(this);

        Button toastButton = findViewById(R.id.toastButton);
        toastButton.setOnClickListener(v -> mostrarMensagem());

        Button tarefaButton = findViewById(R.id.tarefaButton);
        tarefaButton.setOnClickListener(v -> executarTarefa());

    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);

        super.onDestroy();

    }

    @Subscribe
    public void on(TarefaConcluida evento) {
        String mensagem = evento.getMensagem();
        mostrarNotificacao(mensagem);
    }

    private void executarTarefa() {
        new Thread(new Tarefa()).start();
    }

    private void mostrarNotificacao(String mensagem) {

        String id = "meu_canal_id";

        Intent tarefaIntent = new Intent(this, ConfigurarTarefaActivity.class);
        tarefaIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, tarefaIntent, 0);

        Notification.Builder builder = new Notification.Builder(this, id)
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setContentTitle("Minha Notificação")
                .setContentText(mensagem);

        NotificationChannel channel = new NotificationChannel(id, "meu_canal", NotificationManager.IMPORTANCE_DEFAULT);
        channel.setVibrationPattern(new long[]{0,200,200, 200});
        channel.setSound(Uri.parse("android.resource://course/labs/notificacaoapp/" + R.raw.beep), null);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.createNotificationChannel(channel);
        manager.notify(NOTIF_ID, builder.build());


    }

    private void mostrarMensagem() {

        Toast toast = new Toast(this);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);

        View view = getLayoutInflater().inflate(R.layout.toast, null);
        TextView mensagemTextView = view.findViewById(R.id.mensagemTextView);
        mensagemTextView.setText("Olá mundo!");

        toast.setView(view);

        toast.show();

    }

}
