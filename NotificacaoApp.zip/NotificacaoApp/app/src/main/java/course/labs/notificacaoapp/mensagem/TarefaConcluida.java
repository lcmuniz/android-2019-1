package course.labs.notificacaoapp.mensagem;

public class TarefaConcluida {
    private final String mensagem;

    public TarefaConcluida(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getMensagem() {
        return mensagem;
    }

}
