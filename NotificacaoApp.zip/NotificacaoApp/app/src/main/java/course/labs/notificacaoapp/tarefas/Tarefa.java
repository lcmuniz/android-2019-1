package course.labs.notificacaoapp.tarefas;

import org.greenrobot.eventbus.EventBus;

import course.labs.notificacaoapp.mensagem.TarefaConcluida;

public class Tarefa implements Runnable {


    @Override
    public void run() {

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        EventBus.getDefault().post(new TarefaConcluida("eu dormi 3 segundos"));

    }

}
