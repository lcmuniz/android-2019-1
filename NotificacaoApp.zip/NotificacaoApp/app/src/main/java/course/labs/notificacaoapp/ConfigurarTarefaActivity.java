package course.labs.notificacaoapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import org.greenrobot.eventbus.Subscribe;

import course.labs.notificacaoapp.mensagem.TarefaConcluida;

public class ConfigurarTarefaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configurar_tarefa);
    }

}
