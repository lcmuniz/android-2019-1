package com.acme.recyclerviewfragment;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class RCVAdapter extends RecyclerView.Adapter<RCVAdapter.RCVViewHolder> {

    private String[] data;

    public RCVAdapter(String[] data) {
        this.data = data;
    }

    @NonNull
    @Override
    public RCVViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View textView = new TextView(viewGroup.getContext());
        textView.setOnClickListener(v -> onClick(v));
        RCVViewHolder holder = new RCVViewHolder(textView);
        return holder;
    }

    private void onClick(View v) {
        TextView tv = (TextView) v;
        System.out.println(tv.getText().toString());
    }

    @Override
    public void onBindViewHolder(@NonNull RCVViewHolder viewHolder, int i) {
        viewHolder.textView.setText(data[i]);
    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public static class RCVViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;
        public RCVViewHolder(View view) {
            super(view);
            textView = (TextView) view;
        }
    }
}
