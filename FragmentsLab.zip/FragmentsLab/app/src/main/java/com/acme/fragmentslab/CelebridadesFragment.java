package com.acme.fragmentslab;

import android.app.Activity;
import android.app.ListFragment;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CelebridadesFragment extends ListFragment {

	private static final String[] FRIENDS = { "ladygaga", "msrebeccablack",
			"taylorswift13" };
	private static final String TAG = "Lab-Fragments";

	public interface SelectionListener {
		public void onItemSelected(int position);
	}

	private SelectionListener mCallback;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// usa definição de layout diferente, dependendo do dispositivo ser pre- ou pós-honeycomb

		int layout = Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB ? android.R.layout.simple_list_item_activated_1
				: android.R.layout.simple_list_item_1;

		// Confiura o list adapter para este ListFragment
		setListAdapter(new ArrayAdapter<String>(getActivity(), layout, FRIENDS));
	}

		
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);

		// Tenha certeza de que a Activity hospedeira implementou
		// a interface de callback SelectionListener. Precisamos disso
		// pois quando um item neste ListFragment é selecionado,
		// o método onItemSelected() da Activity será chamado.
		
		try {

			mCallback = (SelectionListener) activity;

		} catch (ClassCastException e) {
			throw new ClassCastException(activity.toString()
					+ " precisa implementar SelectionListener");
		}
	}

	// Nota: ListFragments vêm com um método onCreateView() default.
	// Para outros Fragments você normalmente implmentará este método.
	// 	@Override
	//  public View onCreateView(LayoutInflater inflater, ViewGroup container,
	//		Bundle savedInstanceState)

	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		Log.i(TAG, "Entrou em onActivityCreated()");

		// Quando usando layout de dois painéis, configure o ListView para destacar
		// oo item selecionado
		
		if (estaEmModoDoisPaineis()) {

			getListView().setChoiceMode(ListView.CHOICE_MODE_SINGLE);

		}

	}

	@Override
	public void onListItemClick(ListView l, View view, int position, long id) {

		// Notifique a Activity hospedeira de que uma seleção foi feita.

		mCallback.onItemSelected(position);

	}

	// Se tem um FeedFragment, então o layout é de dois painéis
	private boolean estaEmModoDoisPaineis() {

		return getFragmentManager().findFragmentById(R.id.feed_frag) != null;

	}

}
