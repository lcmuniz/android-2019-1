package com.acme.fragmentslab;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends Activity implements
		CelebridadesFragment.SelectionListener {

	private static final String TAG = "Lab-Fragments";

	private CelebridadesFragment mCelebridadesFragment;
	private FeedFragment mFeedFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_activity);

		// Se o layout é de painel único, cria o CelebridadesFragment
		// e adicioná-o à Activity

		if (!estaEmModoDoisPaineis()) {
			
			mCelebridadesFragment = new CelebridadesFragment();

			//TODO 1 - adicionar o CelebrodadesFragment ao fragment_container




			

		} else {

			// Caso contrário, salva a referência ao FeedFragment para uso posterior

			mFeedFragment = (FeedFragment) getFragmentManager()
					.findFragmentById(R.id.feed_frag);
		}

	}

	// Se não existe um ID fragment_container, então a aplicação está em modo de dois painéis

	private boolean estaEmModoDoisPaineis() {

		return findViewById(R.id.fragment_container) == null;
	
	}

	// Mostra o feed do Twitter selecionado

	public void onItemSelected(int position) {

		Log.i(TAG, "Entrou em onItemSelected(" + position + ")");

		// Se não existe uma instância do FeedFragment, então cria uma

		if (mFeedFragment == null)
			mFeedFragment = new FeedFragment();

		// Se está em modo de painel único, substitui o único Fragment visível

		if (!estaEmModoDoisPaineis()) {

			//TODO 2 - substitui o fragment_container com o FeedFragment




			// execute a transação
			getFragmentManager().executePendingTransactions();

		}

		// Atualiza o display do feed do Twitter em FeedFragment
		mFeedFragment.atualizarFeed(position);

	}

}
