package com.acme.fragmentslab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.util.Log;
import android.util.SparseArray;

// Classe utilitária que fornece dados de feed do Twitter

public class FeedFragmentData {
	private static final String TAG = "FeedFragmentData";
	private static final int[] IDS = { R.raw.ladygaga, R.raw.rebeccablack,
			R.raw.taylorswift };
	
	private SparseArray<String> mFeeds = new SparseArray<String>();
	private Context mContext;
	
		
	public FeedFragmentData(Context context) {
		mContext = context;
		carregarFeeds();
	}

	// Carrega todos os feeds do Twitter armazenados em mFeeds.
	
	private void carregarFeeds() {

		for (int id : IDS) {

			InputStream inputStream = mContext.getResources().openRawResource(
					id);
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					inputStream));

			StringBuffer buffer = new StringBuffer("");
			
			
			// Ler raw data do arquivo de recurso
			
			try {

				String linha = "";
				while ((linha = reader.readLine()) != null) {
				
					buffer.append(linha);
				}
			
			} catch (IOException e) {
				Log.i(TAG, "IOException");
			}

			// Converter raw data em uma String

			JSONArray feed = null;
			try {
				feed = new JSONArray(buffer.toString());
			} catch (JSONException e) {
				Log.i(TAG, "JSONException");
			}

			mFeeds.put(id, processarFeed(feed));
		
		}
	}
	
	
	// Converter dados JSON para uma String
	
	private String processarFeed(JSONArray feed) {

		String nome = "";
		String tweet = "";

		// string buffer para os feeds do twitter
		StringBuffer textFeed = new StringBuffer("");

		for (int j = 0; j < feed.length(); j++) {
			try {

				tweet = feed.getJSONObject(j).getString("text");
				JSONObject user = (JSONObject) feed.getJSONObject(j)
						.get("user");
				nome = user.getString("name");

			} catch (JSONException e) {

				Log.i(TAG, "JSONException ao processar feed");
			}

			textFeed.append(nome + " - " + tweet + "\n\n");
		}

		return textFeed.toString();
	}
	
	// Retorna o dado de feed do Twitter para a posição especificada como uma String
	
	 String getFeed (int position) {
		
		return mFeeds.get(IDS[position]);
	
	}
}