package com.acme.gerenciadordetarefas;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class TarefaListAdapter extends BaseAdapter {

	private final List<ItemTarefa> mItems = new ArrayList<ItemTarefa>();
	private final Context mContext;

	private static final String TAG = "Lab-UserInterface";

	public TarefaListAdapter(Context context) {

		mContext = context;

	}

	// Adiciona um ItemTarefa para o adapter
	// Notifica observadores que o dado mudou

	public void add(ItemTarefa item) {

		mItems.add(item);
		notifyDataSetChanged();

	}

	// Limpa todos os itens do adapter

	public void clear() {

		mItems.clear();
		notifyDataSetChanged();

	}

	// retorna o número de itens

	@Override
	public int getCount() {

		return mItems.size();

	}

	// retorno um item

	@Override
	public Object getItem(int pos) {

		return mItems.get(pos);

	}

	// Obtem o ID para o ItemTarefa
	// Neste caso, é apenas a posicao

	@Override
	public long getItemId(int pos) {

		return pos;

	}

	// Cria uma View para o ItemTarefa em uma posicao especificada
	// Lembre de checar se convertView já tem uma View alocada
	// antes de criar uma nova View.
	// Considere usar um padrão ViewHolder para fazer o scrolling mais eficiente
	// Ver: http://developer.android.com/training/improving-layouts/smooth-scrolling.html
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		// TODO - Obtem o ItemTarefa corrente
		final ItemTarefa itemTarefa = null;


		// TODO - Infla a  View para este ItemTarefa
		// a partir do item_tarefa.xml
		RelativeLayout itemLayout = null;




		// Preenche os dados do ItemTarefa
		// Lembre-se que o dado que vai nesta View
		// corresponde aos elementos da interfafe de usuário
		// definidos no arquivo de layout

		// TODO - Mostra o título na TextView
		final TextView tituloView = null;

		// TODO - Configura o CheckBox Status
		final CheckBox statusView = null;


		// TODO - Precisa também configurar um OnCheckedChangeListener,
		// que é chamado quando o usuário alterna o checkbox de status

		statusView.setOnCheckedChangeListener(new OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(CompoundButton buttonView,
							boolean isChecked) {



                        
                        
                        
					}
				});

		// TODO - Mostra a Prioridade em um TextView
		final TextView prioridadeView = null;



		// TODO - Mostra a Hora e a Data.
		// Dica - use ItemTarefa.FORMAT.format(itemTarefa.getDate()) para obter a String de  data e
		// hora
		final TextView dataView = null;

		// Retorna a View criada
		return itemLayout;

	}
}
