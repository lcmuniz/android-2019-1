package com.acme.gerenciadordetarefas;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.content.Intent;

public class ItemTarefa {

	public static final String ITEM_SEP = System.getProperty("line.separator");

	public enum Prioridade {
		BAIXA, MEDIA, ALTA
	};

	public enum Status {
		NAO_CONCLUIDA, CONCLUIDA
	};

	public final static String TITULO = "titulo";
	public final static String PRIORIDADE = "prioridade";
	public final static String STATUS = "status";
	public final static String DATA = "data";
	public final static String FILENAME = "filename";

	public final static SimpleDateFormat FORMAT = new SimpleDateFormat(
			"dd-MM-yyyy HH:mm:ss", Locale.FRANCE);

	private String mTitulo = new String();
	private Prioridade mPrioridade = Prioridade.BAIXA;
	private Status mStatus = Status.NAO_CONCLUIDA;
	private Date mData = new Date();

	ItemTarefa(String titulo, Prioridade prioridade, Status status, Date data) {
		this.mTitulo = titulo;
		this.mPrioridade = prioridade;
		this.mStatus = status;
		this.mData = data;
	}

	// Cria um novo ItemTarefa do data empacotado em uma Intent

	ItemTarefa(Intent intent) {

		mTitulo = intent.getStringExtra(ItemTarefa.TITULO);
		mPrioridade = Prioridade.valueOf(intent.getStringExtra(ItemTarefa.PRIORIDADE));
		mStatus = Status.valueOf(intent.getStringExtra(ItemTarefa.STATUS));

		try {
			mData = ItemTarefa.FORMAT.parse(intent.getStringExtra(ItemTarefa.DATA));
		} catch (ParseException e) {
			mData = new Date();
		}
	}

	public String getTitulo() {
		return mTitulo;
	}

	public void setTitulo(String titulo) {
		mTitulo = titulo;
	}

	public Prioridade getPrioridade() {
		return mPrioridade;
	}

	public void setPrioridade(Prioridade prioridade) {
		mPrioridade = prioridade;
	}

	public Status getStatus() {
		return mStatus;
	}

	public void setStatus(Status status) {
		mStatus = status;
	}

	public Date getData() {
		return mData;
	}

	public void setData(Date data) {
		mData = data;
	}

	// Pega um conjunto de valores de dados String e
	// empacota-os para transporte em uma Intent

	public static void packageIntent(Intent intent, String titulo,
									 Prioridade prioridade, Status status, String data) {

		intent.putExtra(ItemTarefa.TITULO, titulo);
		intent.putExtra(ItemTarefa.PRIORIDADE, prioridade.toString());
		intent.putExtra(ItemTarefa.STATUS, status.toString());
		intent.putExtra(ItemTarefa.DATA, data);
	
	}

	public String toString() {
		return mTitulo + ITEM_SEP + mPrioridade + ITEM_SEP + mStatus + ITEM_SEP
				+ FORMAT.format(mData);
	}

	public String toLog() {
		return "Título:" + mTitulo + ITEM_SEP + "Prioridade:" + mPrioridade
				+ ITEM_SEP + "Status:" + mStatus + ITEM_SEP + "Data:"
				+ FORMAT.format(mData) + "\n";
	}

}
