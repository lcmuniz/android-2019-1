package com.acme.gerenciadordetarefas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.Date;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.acme.gerenciadordetarefas.ItemTarefa.Prioridade;
import com.acme.gerenciadordetarefas.ItemTarefa.Status;

public class MainActivity extends ListActivity {

    private static final int ADICIONAR_TAREFA_REQUEST = 0;
    private static final String FILE_NAME = "GerenciadorTarefasActivityData.txt";
    private static final String TAG = "Lab-UserInterface";

    // IDs for menu items
    private static final int MENU_DELETE = Menu.FIRST;
    private static final int MENU_DUMP = Menu.FIRST + 1;

    TarefaListAdapter mAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Cria um novo TarefaListAdapter para a ListView desta ListActivity
        mAdapter = new TarefaListAdapter(getApplicationContext());

        // Coloca um divisor entre os ItemTarefa and FooterView
        getListView().setFooterDividersEnabled(true);

        // TODO - Inflaar footerView de footer_view.xml file
        TextView footerView = null;

        // NOTA: Você pode remover este bloco uma vez que tenha implementado esta tarefa
        if (null == footerView) {
            return;
        }
        // TODO - Adicionar footerView à ListView



        // TODO - Anexar o Listener à FooterView
        footerView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {


                //TODO - Implementar OnClick().

            }
        });

        // TODO - Anexar o adapter para a ListView desta ListActivity

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Log.i(TAG,"Entrou em onActivityResult()");

        // TODO - Checar o result code e o request code
        // se usuário submeteu um novo ItemTarefa
        // Criar um novo ItemTarefa a partir do data da Intent
        // e então adicioná-lo ao adapter


    }

    // Não modifique a partir daqui

    @Override
    public void onResume() {
        super.onResume();

        // Carrega itens salvos, se necessario

        if (mAdapter.getCount() == 0)
            loadItems();
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Salva itens

        saveItems();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        menu.add(Menu.NONE, MENU_DELETE, Menu.NONE, "Excluir tudo");
        menu.add(Menu.NONE, MENU_DUMP, Menu.NONE, "Dump to log");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case MENU_DELETE:
                mAdapter.clear();
                return true;
            case MENU_DUMP:
                dump();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void dump() {

        for (int i = 0; i < mAdapter.getCount(); i++) {
            String data = ((ItemTarefa) mAdapter.getItem(i)).toLog();
            Log.i(TAG,	"Item " + i + ": " + data.replace(ItemTarefa.ITEM_SEP, ","));
        }

    }

    // Carregar itens salvos
    private void loadItems() {
        BufferedReader reader = null;
        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            reader = new BufferedReader(new InputStreamReader(fis));

            String titulo = null;
            String prioridade = null;
            String status = null;
            Date data = null;

            while (null != (titulo = reader.readLine())) {
                prioridade = reader.readLine();
                status = reader.readLine();
                data = ItemTarefa.FORMAT.parse(reader.readLine());
                mAdapter.add(new ItemTarefa(titulo, Prioridade.valueOf(prioridade),
                        Status.valueOf(status), data));
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        } finally {
            if (null != reader) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Salvar ItemTarefa para arquivo
    private void saveItems() {
        PrintWriter writer = null;
        try {
            FileOutputStream fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
            writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(
                    fos)));

            for (int idx = 0; idx < mAdapter.getCount(); idx++) {

                writer.println(mAdapter.getItem(idx));

            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != writer) {
                writer.close();
            }
        }
    }
}