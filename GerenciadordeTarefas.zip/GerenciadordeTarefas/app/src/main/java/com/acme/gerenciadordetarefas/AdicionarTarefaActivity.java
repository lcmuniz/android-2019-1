package com.acme.gerenciadordetarefas;

import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import com.acme.gerenciadordetarefas.ItemTarefa.Prioridade;
import com.acme.gerenciadordetarefas.ItemTarefa.Status;

public class AdicionarTarefaActivity extends Activity {

	// 7 days in milliseconds - 7 * 24 * 60 * 60 * 1000
	private static final int SEVEN_DAYS = 604800000;

	private static final String TAG = "Lab-UserInterface";

	private static String horaString;
	private static String dataString;
	private static TextView dataView;
	private static TextView horaView;

	private Date mData;
	private RadioGroup mPrioridadeRadioGroup;
	private RadioGroup mStatusRadioGroup;
	private EditText mTituloText;
	private RadioButton mDefaultStatusButton;
	private RadioButton mDefaultPrioridadeButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.adicionar_tarefa);

		mTituloText = (EditText) findViewById(R.id.titulo);
		mDefaultStatusButton = (RadioButton) findViewById(R.id.statusNaoConcluido);
		mDefaultPrioridadeButton = (RadioButton) findViewById(R.id.mediaPrioridade);
		mPrioridadeRadioGroup = (RadioGroup) findViewById(R.id.prioridadeGroup);
		mStatusRadioGroup = (RadioGroup) findViewById(R.id.statusGroup);
		dataView = (TextView) findViewById(R.id.data);
		horaView = (TextView) findViewById(R.id.hora);

		// Configura a data e hora padrao

		setDefaultDateTime();

		// OnClickListener para o botao Data , chama showDatePickerDialog() para
		// mostrar o dialogo da Data

		final Button datePickerButton = (Button) findViewById(R.id.date_picker_button);
		datePickerButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				showDatePickerDialog();
			}
		});

		// OnClickListener para o botao Hora, chama showTimePickerDialog() para
		// mostrar o dialogo Hora

		final Button timePickerButton = (Button) findViewById(R.id.time_picker_button);
		timePickerButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				showTimePickerDialog();
			}
		});

		// OnClickListener para o botao Cancelar,

		final Button cancelarButton = (Button) findViewById(R.id.cancelarButton);
		cancelarButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {



				// TODO - Indicar o resultado e finalizar


			}
		});

		// TODO - Configurar OnClickListener para o botao Reiniciar
		final Button reiniciarButton = (Button) findViewById(R.id.reiniciarButton);
		reiniciarButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {


				// TODO - Reiniciar data para os valores padrao


				// resetar data e hora
				setDefaultDateTime();

			}
		});

		// Configura OnClickListener para o botao Enviar

		final Button enviarButton = (Button) findViewById(R.id.enviarButton);
		enviarButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {


				// pega os dados da ItemTarefa


				// TODO - Obtem a prioridade corrente
				Prioridade prioridade = null;

				// TODO - Obtem o Status corrente
				Status status = null;

				// TODO - Obtem o Título corrente


				String tituloString = null;

				// Constroi a string da data
				String dataCompleta = dataString + " " + horaString;

				// Empacota ItemTarefa na Intent
				Intent data = new Intent();
				ItemTarefa.packageIntent(data, tituloString, prioridade, status,
						dataCompleta);

				// TODO - retornar o data da Intent e finalizar


			}
		    });
	}

	// Não modificar depois deste ponto.

	private void setDefaultDateTime() {

		// Padrao é hora atual + 7 dias
		mData = new Date();
		mData = new Date(mData.getTime() + SEVEN_DAYS);

		Calendar c = Calendar.getInstance();
		c.setTime(mData);

		setDateString(c.get(Calendar.YEAR), c.get(Calendar.MONTH),
				c.get(Calendar.DAY_OF_MONTH));

		dataView.setText(dataString);

		setTimeString(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE),
				c.get(Calendar.MILLISECOND));

		horaView.setText(horaString);
	}

	private static void setDateString(int year, int monthOfYear, int dayOfMonth) {

		// Incrementa monthOfYear para Calendar/Date -> Time Format setting
		monthOfYear++;
		String mon = "" + monthOfYear;
		String day = "" + dayOfMonth;

		if (monthOfYear < 10)
			mon = "0" + monthOfYear;
		if (dayOfMonth < 10)
			day = "0" + dayOfMonth;

		dataString = year + "-" + mon + "-" + day;
	}

	private static void setTimeString(int hourOfDay, int minute, int mili) {
		String hour = "" + hourOfDay;
		String min = "" + minute;

		if (hourOfDay < 10)
			hour = "0" + hourOfDay;
		if (minute < 10)
			min = "0" + minute;

		horaString = hour + ":" + min + ":00";
	}

	private Prioridade getPriority() {

		switch (mPrioridadeRadioGroup.getCheckedRadioButtonId()) {
		case R.id.baixaPrioridade: {
			return Prioridade.BAIXA;
		}
		case R.id.altaPrioridade: {
			return Prioridade.ALTA;
		}
		default: {
			return Prioridade.MEDIA;
		}
		}
	}

	private Status getStatus() {

		switch (mStatusRadioGroup.getCheckedRadioButtonId()) {
		case R.id.statusDone: {
			return Status.CONCLUIDA;
		}
		default: {
			return Status.NAO_CONCLUIDA;
		}
		}
	}

	private String getTituloTarefa() {
		return mTituloText.getText().toString();
	}
	
	
	// DialogFragment usada para pegar uma data limite da ItemTarefa

	public static class DatePickerFragment extends DialogFragment implements
			DatePickerDialog.OnDateSetListener {

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {

			// Usa a data corrente como a data padrao

			final Calendar c = Calendar.getInstance();
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH);
			int day = c.get(Calendar.DAY_OF_MONTH);

			// Cria uma nova isntancia do DatePickerDialog e o retorna
			return new DatePickerDialog(getActivity(), this, year, month, day);
		}

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			setDateString(year, monthOfYear, dayOfMonth);

			dataView.setText(dataString);
		}

	}

	// DialogFragment usado  para pegar uma hora lmiite de ItemTarefa

	public static class TimePickerFragment extends DialogFragment implements
			TimePickerDialog.OnTimeSetListener {

		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) {

			// Usa a hora corrente como valor padrao
			final Calendar c = Calendar.getInstance();
			int hour = c.get(Calendar.HOUR_OF_DAY);
			int minute = c.get(Calendar.MINUTE);

			// Cria uma nova instancia de TimePickerDialog e o retorna
			return new TimePickerDialog(getActivity(), this, hour, minute, true);
		}

		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			setTimeString(hourOfDay, minute, 0);

			horaView.setText(horaString);
		}
	}

	private void showDatePickerDialog() {
		DialogFragment newFragment = new DatePickerFragment();
		newFragment.show(getFragmentManager(), "datePicker");
	}

	private void showTimePickerDialog() {
		DialogFragment newFragment = new TimePickerFragment();
		newFragment.show(getFragmentManager(), "timePicker");
	}
}
