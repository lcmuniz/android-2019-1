package com.acme.alarmsapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final long CINCO_SEGUNDOS = 5000L;

    AlarmManager alarmManager;

    Intent notificationReceiverIntent;
    PendingIntent notificationReceiverPendingIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // obter o AlarmManager
        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        // criar a pending intent para iniciar o AlarmNotificationReceiver
        notificationReceiverIntent = new Intent(this, AlarmNotificationReceiver.class);
        notificationReceiverPendingIntent = PendingIntent.getBroadcast(this, 0 ,
                notificationReceiverIntent, 0);

        Button setSingleAlarmButton = findViewById(R.id.setSingleAlarmButton);
        setSingleAlarmButton.setOnClickListener(v -> setSingleAlarm());

        Button setRepeatingAlarmButton = findViewById(R.id.setRepeatingAlarmButton);
        setRepeatingAlarmButton.setOnClickListener(v -> setRepeatingAlarm());

        Button setInexactRepeatingAlarmButton = findViewById(R.id.setInexactRepeatingAlarmButton);
        setInexactRepeatingAlarmButton.setOnClickListener(v -> setInexactRepeatingAlarm());

        Button cancelRepeatingAlarmButton = findViewById(R.id.cancelRepeatingAlarmButton);
        cancelRepeatingAlarmButton.setOnClickListener(v -> cancelRepeatingAlarm());
    }

    private void
    setSingleAlarm() {
        alarmManager.set(AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + CINCO_SEGUNDOS,
                notificationReceiverPendingIntent);

        Toast.makeText(this, "Single Alarm Set", Toast.LENGTH_LONG).show();
    }

    private void setRepeatingAlarm() {
        alarmManager.setRepeating(AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + CINCO_SEGUNDOS,
                AlarmManager.INTERVAL_FIFTEEN_MINUTES,
                notificationReceiverPendingIntent);

        Toast.makeText(this, "Repeating Alarm Set", Toast.LENGTH_LONG).show();
    }

    private void setInexactRepeatingAlarm() {
        alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + CINCO_SEGUNDOS,
                AlarmManager.INTERVAL_FIFTEEN_MINUTES,
                notificationReceiverPendingIntent);

        Toast.makeText(this, "Inexact Repeating Alarm Set", Toast.LENGTH_LONG).show();
    }

    private void cancelRepeatingAlarm() {
        alarmManager.cancel(notificationReceiverPendingIntent);
        Toast.makeText(this, "Repeating Alarm Cancelled", Toast.LENGTH_LONG).show();
    }

}
