package com.acme.permissaolab;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

	private static final String TAG = "Lab-Permisssao";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Button enviarSMSButton = (Button) findViewById(R.id.enviar_sms_button);
		enviarSMSButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				iniciarSmsActivity();
			
			}
		});
	}

	private void iniciarSmsActivity() {
		
		Log.i(TAG, "Entrou em iniciarSmsActivity()");
	
		// TODO - Iniciar a SMSActivity

	}
}
