package com.acme.permissaolab;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class SMSActivity extends Activity {
	
	private static final String TAG = "Lab-Permisssao";

	private static final int REQUEST_SEND_SMS =0 ;

	private String phoneNo = "555-5555";
	private String message = "Este é um SMS!";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sms_activity);

		Button getBookmarksButton = (Button) findViewById(R.id.sms_button);
		getBookmarksButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				sendSMSMessage();

			}
		});

		Button goToDangerousActivityButton = (Button) findViewById(R.id.perigo_button);
		goToDangerousActivityButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				iniciarIrParaPerigoActivity();

			}
		});

	}

	protected void sendSMSMessage() {
		if (ContextCompat.checkSelfPermission(this,
				Manifest.permission.SEND_SMS)
				!= PackageManager.PERMISSION_GRANTED) {
			if (ActivityCompat.shouldShowRequestPermissionRationale(this,
					Manifest.permission.SEND_SMS)) {
			} else {
				ActivityCompat.requestPermissions(this,
						new String[]{Manifest.permission.SEND_SMS},
						REQUEST_SEND_SMS);
			}
		}
	}

	private void iniciarIrParaPerigoActivity() {

		Log.i(TAG, "Entrou em iniciarIrParaPerigoActivity()");

		// TODO - Iniciar IrParaPerigoActivity
		startActivity(new Intent(this, IrParaPerigoActivity.class));

	}

	@Override
	public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
		switch (requestCode) {
			case REQUEST_SEND_SMS: {
				if (grantResults.length > 0
						&& grantResults[0] == PackageManager.PERMISSION_GRANTED) {
					SmsManager smsManager = SmsManager.getDefault();
					smsManager.sendTextMessage(phoneNo, null, message, null, null);
					Toast.makeText(getApplicationContext(), "SMS enviado.",
							Toast.LENGTH_LONG).show();
				} else {
					Toast.makeText(getApplicationContext(),
							"SMS falhou, tente novamente.", Toast.LENGTH_LONG).show();
					return;
				}
			}
		}

	}

}
