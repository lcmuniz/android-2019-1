package com.acme.permissaolab;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class IrParaPerigoActivity extends Activity {
	
	private static final String TAG = "Lab-Permisssao";

	private static final String PERIGO_ACTIVITY_ACTION = "com.acme.permissaolab.PERIGO_ACTIVITY_ACTION";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ir_para_perigo_activity);

		Button iniciarPerigoActivityButton = (Button) findViewById(R.id.iniciar_perigo_activity_button);
		iniciarPerigoActivityButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				iniciarPerigoActivity();

			}
		});

	}

	private void iniciarPerigoActivity() {

		Log.i(TAG, "Entrou em iniciarPerigoActivity()");

		startActivity(new Intent(PERIGO_ACTIVITY_ACTION));
		

	}

}
