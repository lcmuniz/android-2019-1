package course.labs.meunavegador;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String url = getIntent().getDataString();

        if (null == url)
            url = "Nenhum Dado Fornecido";

        // Obtém uma referência ao TextView e define o seu texto como a URL
        TextView textView = findViewById(R.id.url);
        textView.setText(url);

    }
}
