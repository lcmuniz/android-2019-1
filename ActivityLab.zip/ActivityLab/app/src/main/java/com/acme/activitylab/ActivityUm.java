package com.acme.activitylab;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class ActivityUm extends AppCompatActivity {

    // Use essas chaves quando estiver salvando o estado entre as reconfigurações
    private static final String RESTART_KEY = "restart";
    private static final String RESUME_KEY = "resume";
    private static final String START_KEY = "start";
    private static final String CREATE_KEY = "create";

    // String para o LogCat
    private final static String TAG = ActivityUm.class.getSimpleName();

    // Contadores de ciclo de vida

    // TODO:
    // Criar variáveis chamadas
    // mCreate, mRestart, mStart e mResume
    // para contar as chamadas para os métodos onCreate(), onRestart(), onStart() e
    // onResume(). Estas variáveis não devem ser definidas como static.

    // Você precisará incrementar estas variáveis quando os
    // ciclos de vida correspondentes forem chamados.

    // TODO: Criar variáveis para cada uma das TextView
    // chamdadas mTvCreate, mTvRestart, mTvStart, mTvResume.
    // para mostrar a contagem corrente de cada variável
    // mCreate, mRestart, mStart and mResume.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_um);

        // TODO: Atribuir os TextViews apropriados às variaǘeis TextView
        // Dica: Acesse o TextView chamando o método findViewById()
        // textView1 = findViewById(R.id.textView1);

        Button iniciarActivityDoisButton = findViewById(R.id.bIniciarActivityDois);
        iniciarActivityDoisButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO:
                // Iniciar a ActivityDois
                // Dica: use o método startActivity() method

                // Criar uma intent informando qual Activity você
                // deseja iniciar
                Intent intent = null;

                // Inicie a Activity usando a intent

            }
        });

        // O estado anterior foi salvo?
        if (savedInstanceState != null) {

            // TODO:
            // Restaurar os valores dos contadores do estado salvo
            // Somente precisa de 4 linhas de código, uma para cada contador

        }

        // Gravar mensagem no LogCat
        Log.i(TAG, "Entrou no método onCreate()");

        // TODO:
        // Atualizar a variável contadora apropriada
        // Atualizar a interface de usuário via o método mostrarContadores()

    }

    // Métodos do ciclo de vida

    @Override
    public void onStart() {
        super.onStart();

        // Gravar mensagem no LogCat
        Log.i(TAG, "Entrou no método onStart()");

        // TODO:
        // Atualizar a variável contadora apropriada
        // Atualizar a interface de usuário

    }

    @Override
    public void onResume() {
        super.onResume();

        // Gravar mensagem no LogCat
        Log.i(TAG, "Entrou no método onResume()");

        // TODO:
        // Atualizar a variável contadora apropriada
        // Atualizar a interface de usuário

    }

    @Override
    public void onPause() {
        super.onPause();

        // Gravar mensagem no LogCat
        Log.i(TAG, "Entrou no método onPause()");
    }

    @Override
    public void onStop() {
        super.onStop();

        // Gravar mensagem no LogCat
        Log.i(TAG, "Entrou no método onStop()");
    }

    @Override
    public void onRestart() {
        super.onRestart();

        // Gravar mensagem no LogCat
        Log.i(TAG, "Entrou no método onRestart()");

        // TODO:
        // Atualizar a variável contadora apropriada
        // Atualizar a interface de usuário

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        // Gravar mensagem no LogCat
        Log.i(TAG, "Entrou no método onDestroy()");
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        // TODO:
        // Salvar a informação do estado  como uma coleção de pares chave-valor
        // 4 linas de código, uma para cada variável contadora

    }

    // Atualiza os contadores mostrados
    // Este método espera que os contadores e as variáveis TextView
    // use os nomes especificados acima
    public void mostrarContadores() {

        // TODO - descomente estas linhas
	/*
		mTvCreate.setText("Chamadas a onCreate(): " + mCreate);
		mTvStart.setText("Chamadas a onStart(): " + mStart);
		mTvResume.setText("Chamadas a onResume(): " + mResume);
		mTvRestart.setText("Chamadas a onRestart(): " + mRestart);
	*/
    }
}