package com.acme.aresposta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public final int[] respostas = {42, -10, 0, 100, 1000};
    public final int aResposta = 42;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView respostaTextView = findViewById(R.id.respostaTextView);

        int val = encontrarResposta();
        String resposta = (val == aResposta) ? "42" : "Nunca saberemos";

        respostaTextView.setText(resposta);


    }

    private int encontrarResposta() {
        for (int val : respostas) {
            if ( val != aResposta) {
                return val;
            }
        }
        return -1;
    }
}
