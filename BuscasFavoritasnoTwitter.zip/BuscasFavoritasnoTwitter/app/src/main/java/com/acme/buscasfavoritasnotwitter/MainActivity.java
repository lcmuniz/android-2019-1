package com.acme.buscasfavoritasnotwitter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences pesquisasSalvas;
    private TableLayout pesquisasTableLayout;
    private EditText pesquisaEditText;
    private EditText marcaEditText;

    // chamado quando a activity é criada
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // obtem o objeto SharedPreferences que contem as pesquisas do usuario
        pesquisasSalvas = getSharedPreferences("pesquisas", MODE_PRIVATE);

        pesquisasTableLayout = findViewById(R.id.pesquisasTableLayout);

        pesquisaEditText = findViewById(R.id.pesquisaEditText);
        marcaEditText = findViewById(R.id.marcaEditText);

        Button salvarButton = findViewById(R.id.salvarButton);
        salvarButton.setOnClickListener(salvarButtonListener);

        Button limparPesquisasButton = findViewById(R.id.limparPesquisasButton);
        limparPesquisasButton.setOnClickListener(limparPesquisasButtonListener);

        // adiciona as pesquisas salvas anteriormente
        atualizarButtons(null);

    }

    // recria os componentes Button de marca de pesquisa e edição
    // para todas as pesquisas salvas
    private void atualizarButtons(String novaMarca) {

        // armazena marcas salvas no array marcas
        String[] marcas = pesquisasSalvas.getAll().keySet().toArray(new String[0]);
        Arrays.sort(marcas, String.CASE_INSENSITIVE_ORDER);

        // se uma nova marca foi adicionada, insere na gui no local apropriado
        if (novaMarca != null) {
            criarTableRow(novaMarca, Arrays.binarySearch(marcas, novaMarca));
        }
        else {
            // exibe todas as pesquisas salvas
            for (int index = 0; index < marcas.length; index++) {
                criarTableRow(marcas[index], index);
            }
        }
    }

    // adciona nova pesquisa no arquivo de salvamento e então atualiza todos os Buttons
    private void salvaPesquisa(String pesquisa, String marca) {

        // novaPesquisa vai ser null se estivermos modificando uma pesquisa ja existente
        String novaPesquisa = pesquisasSalvas.getString(marca, null);

        // obtem um SharedPreferences.Editor para armazenar o novo par marca/consulta
        SharedPreferences.Editor preferencesEditor = pesquisasSalvas.edit();
        preferencesEditor.putString(marca, pesquisa);
        preferencesEditor.apply();

        // se essa é uma nova consulta, adiciona sua interface gráfica
        if (novaPesquisa == null) {
            atualizarButtons(marca);
        }
    }

    // adiciona um novo botão marca e botão de edição correspondente na interface gráfica
    private void criarTableRow(String marca, int index) {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // infla nova_marca_view para criar novos componentes Button de marca e edição
        View novaMarcaView = inflater.inflate(R.layout.nova_marca_view, null);

        Button marcaButton = novaMarcaView.findViewById(R.id.marcaButton);
        marcaButton.setText(marca);
        marcaButton.setOnClickListener(pesquisaButtonListener);

        Button editButton = novaMarcaView.findViewById(R.id.editButton);
        editButton.setOnClickListener(editarButtonListener);

        // adiciona novos botões de marca e edição no componente queyTableLayout
        pesquisasTableLayout.addView(novaMarcaView, index);
    }

    // remove do aplicativo todos os componentes Button de pesquisa salva
    private void limparButtons() {
        pesquisasTableLayout.removeAllViews();
    }

    // cria um novo componente Button e o adiciona no elemento ScrollView
    private View.OnClickListener salvarButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            // cria a marca se queryEditTExt e marcaEditText não estão vazios
            if (pesquisaEditText.getText().length() > 0 && marcaEditText.getText().length() > 0) {
                salvaPesquisa(pesquisaEditText.getText().toString(), marcaEditText.getText().toString());
                pesquisaEditText.setText("");
                marcaEditText.setText("");

                // oculta o teclado virtual
                ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(marcaEditText.getWindowToken(), 0);
            }
            else {
                // exibe uma mensagem pedindo para que o usuário foneça uma consulta e uma marca

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                builder.setTitle(R.string.tituloAusente);

                builder.setPositiveButton(R.string.OK, null);

                builder.setMessage(R.string.mensagemAusente);

                AlertDialog errorDialog = builder.create();
                errorDialog.show();
            }

        }
    };

    // apaga todas as pesquisas salvas
    private View.OnClickListener limparPesquisasButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

            builder.setTitle(R.string.tituloConfirmacao);

            builder.setPositiveButton(R.string.apagar, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // apaga todas as pesquisas salvas
                    limparButtons();

                    // obtem um SharedPreferences.Editor para limpar as pesquisas
                    SharedPreferences.Editor preferencesEditor = pesquisasSalvas.edit();
                    // remove todos os pares marca/consulta
                    preferencesEditor.clear();
                    preferencesEditor.apply();
                }
            });

            builder.setCancelable(true);
            builder.setNegativeButton(R.string.calcelar, null);

            builder.setMessage(R.string.mensagemConfirmacao);

            AlertDialog confirmDialog = builder.create();
            confirmDialog.show();
        }
    };

    // carrega a pesquisa selecionada em um navegador web
    private View.OnClickListener pesquisaButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            // obtem a consulta
            String textoBotao = ((Button) v).getText().toString();
            String pesquisa = pesquisasSalvas.getString(textoBotao, null);

            // cria a URL correspondente à consulta do componente Button tocado
            String urlString = getString(R.string.urlPesquisa) + pesquisa;

            // cria uma Intent para ativar o navegador web
            Intent getURL = new Intent(Intent.ACTION_VIEW, Uri.parse(urlString));

            startActivity(getURL);

        }
    };

    // edita a pesquisa selecionada
    private View.OnClickListener editarButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            TableRow buttonTableRow = (TableRow) v.getParent();
            Button marcaButton = buttonTableRow.findViewById(R.id.marcaButton);

            String marca = marcaButton.getText().toString();

            // configura os componentes EdiText para corresponder à marca e à consulta escolhida
            marcaEditText.setText(marca);
            pesquisaEditText.setText(pesquisasSalvas.getString(marca, null));
        }
    };

}
